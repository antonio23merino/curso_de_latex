########################################################################################
#########################         CURSO R - BÁSICO           ########################### 
########################################################################################
######################################################################################## 
#############################        PROYECTO FINAL        ############################# 
########################################################################################
#             INTEGRANTES: - Kevin Aguirre                                             #
#                          - Priscila Constante                                        #
#                          - Karina Parra                                              #
########################################################################################
######################################################################################## 
#install.packages(readxl)
library(xtable)
library(readxl)
options(digits = 3)

data1<-read_excel("Base-de-Datos_Proyecto.xlsx", sheet=1, na=" ")
View(head(data1))

#observaciones:
observaciones<-nrow(data1)
#variables
variables<-ncol(data1)

  #Dimensiones
str(data1)

#la clase de cada variable de nuestra data
clase<-function(data){
  v<-character(ncol(data))
  
  for (i in 1:ncol(data)){
    v[i]<-class(data[,i])
  }
  cl<-data.frame(names(data),v)
  cl
} 
clase(data1)


#Frecuencia de tickets en cada Mes 
fmes<-table(data1$MES)
fmes
(barplot(fmes,ylab = "Frecuencias",xlab = "Meses",
        main = "Llamadas por mes",col = c("coral", "coral2","coral4")))


#Frecuencia de tickets en cada Mes por vendedor 
fvendedor<-subset(data1,select=c("NOMBRES","MES"))
fvendedor
tablevendedor<-table(fvendedor)
tvendedor<-as.data.frame.matrix(tablevendedor)
View(tvendedor)
t<-apply(tvendedor,2,max)
barplot(t,ylab = "Frecuencias",xlab = "Meses",
        main = "Persona con más tickets por mes",
        legend.text = c("Chalá Noemí","Lozada Pablo","Haro Bethy"),
        col = c("lavender","lavenderblush","lavenderblush2"))


#Frecuencia de tickets en cada Mes por tipo de solicitudes
ftipo<-subset(data1,select=c("NOMBRES","TIPO"))
tipo<-table(ftipo)
tipo1<-as.data.frame.matrix(tipo)
View(tipo1)
tipo1



#frecuencias de tipos de reclamos en cada mes
fr<-subset(data1,select=c("MES","TIPO"))
(t<-table(fr))
(barplot(t,ylab = "Frecuencias",xlab = "Tipos de Llamadas",
        main = "Tipos de Llamadas por mes",
        col = c("magenta","red","pink"),
        legend.text = c("Enero","Febrero","Marzo")))



######################


#SPLIT

nuevadata<-split(data1,data1$TIPO)

#Data de reclamos

reclamo1<-nuevadata$`RECLAMOS COMERCIAL`

reclamo<-subset(reclamo1,select=c(CATEGORIA,MES))
reclamotabla<-table(reclamo)
reclamotabla
xtable(reclamotabla)



#Data de solicitudes
solicitud1<-nuevadata$`SOLICITUD COMERCIAL`
solicitud1<-subset(solicitud1,select=c(CATEGORIA,MES))
solicitudtabla<-table(solicitud1)
solicitudtabla
xtable(solicitudtabla)


# de mes y estado
data2<-subset(data1,select = c(MES,ESTADO))
table(data2)
mesyestado<-(table(data2))
xtable(mesyestado)
barplot(mesyestado,col=c("red","blue","green"),legend.text = c("Enero","Febrero","Marzo"))



#########################Viendo los clientes nuevos######################
data1cat<-split(data1, data1$CATEGORIA)######HACIENO LA NUEV BASE DE DATOS
clientnew<-data1cat$'CLIENTE NUEVO'#Q SOLO TENGA CLIENTES NUEVOS
clientnew###SOLO VEO Q ESTE BIEN
View(head(clientnew))#ME ASEGUO Q ESTE BN
table(clientnew$MES)#SON LAS FREC
a<-table(clientnew$MES)#LAS FRECUENCIAS GUARDO EN UNA VARIABLE
prop.table(table(clientnew$MES))#ESTOS SON LOS PORCENTAJES
b<-prop.table(table(clientnew$MES))#LAS PORCENTAJES GUARDO
xtable((table(clientnew$MES)))

barplot(a,col=c("palegreen","rosybrown1","paleturquoise1"),xlab = "Meses",ylab = "Frecuencias",main = "Clientes nuevos por mes")

##########################
#Indices cIERRE VS IND SOL
dataindi<-subset(data1, select=c('IND. SOLUCION','IND. CIERRE'))
View(head(dataindi))
c<-table(dataindi)
xtable(c) 
c<-table(dataindi)
barplot(c,legend.text=c('A TIEMPO','ALERTA','TARDE'))
#############


